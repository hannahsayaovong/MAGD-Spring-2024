
var img1;
var img2;

function preload() {

  img1 = loadImage("jun.jpg");
  img2 = loadImage("the8.jpg");


}

function setup () {

  createCanvas(480, 420);
  
    textFont("Arial");
    fill(250);
    stroke(0);
    strokeWeight(6);
  }

function draw () {

  image(img1, -120, 0);
  
  image(img2, 0, 0, mouseX * 2, mouseY * 2);

  image(img1, 130, 0, 120, 60);

  image(img2, 300, 0, 240, 120);

    textSize(40);

  text("SEVENTEEN right here!", 25, 230);
}