var x = []; 

function setup() {

  createCanvas(400, 400);

  noStroke();

  fill(755, 800);

  for (var i = 0; i < 2500; i++) {

    x[i] = random(-4500, 300); 

  }

}

function draw() {

  background(0);

  for (var i = 0; i < x.length; i++) {

    x[i] +=2.5;

    var y = i * 0.4;

    circle(x[i], y, 14);
      
      x[0] = mouseX;
      y[0] = mouseY;
        ellipse(x[i], 50, 50, 50);
      }

}