function setup() {
  
  createCanvas(400, 400);
  print('hello, world');
  
}

function draw() {
  
  background(180);
  
  ellipseMode(CENTER);
  translate(width / 2.5, height / 5);
  translate(p5.Vector.fromAngle(millis() / 1000, 40));
  ellipse (0, 0, 30, 30);
  
  for (var x = 25; x < width + 70; x += 80) {
    spots(x, 240);
      
  const c= color('blue');
  fill(c);
  noStroke();      
  ellipse(30, 20, 50, 50);
  scale(0.5);
  ellipse(30, 20, 50, 50);
      
      let r = 40;
push();
rotate(PI / 6);
line(0, 0, r, 0);
text('0.524 rad', r, 0);
pop();

angleMode(DEGREES);
push();
rotate(60);
line(0, 0, r, 0);
text('60˚', r, 0);
pop();

describe('Two diagonal lines radiating from the top left corner of a square. The lines are oriented 30 degrees from the edges of the square and 30 degrees apart from each other.');
      
      
  }
}

function spots(x, y) {
  
  push();

  translate(x, y);

  stroke(0);

  strokeWeight(100);

  line (0, -75, 0, -75); // Black

  noStroke();

  fill(355);

  ellipse(-17.5, -65, 35, 35); // white eft eye 

  ellipse(17.5, -65, 35, 35); // white right eye 

  fill(0);

  ellipse(-14, -65, 8, 8); // black left dot

  ellipse(14, -65, 8, 8); // black right dot

  pop(); // return the drawing state to it's original state, before the push() function

}